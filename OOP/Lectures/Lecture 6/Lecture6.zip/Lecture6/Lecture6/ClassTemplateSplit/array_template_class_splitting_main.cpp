#include "array_template_class_splitting.h"
#include "array_template_class_splitting.cpp"
#include <iostream>

template class Array<int>; // Explicitly instantiate template Array<int>
template class Array<double>; // Explicitly instantiate template Array<double>


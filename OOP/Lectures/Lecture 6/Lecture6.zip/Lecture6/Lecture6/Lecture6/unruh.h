#ifndef UNRUH_H
#define UNRUH_H


class unruh
{
public:
    unruh();
};

#endif // UNRUH_H

#include <iomanip>
#include <iostream>
#include <cassert>
using namespace std;

#include "DynamicArray.h"

int main() {
	// collections that store elements of the same type
	// array - fixed size (int a[100];) contigiulsy allocated in the memory
	// vector - dynamic array for which we can modify the size 
	// (int* x = new int[100]; x = new int[200]); std::vector<int> v; contigoiulsy allocated in the memory
	// array and vector = random access x[10], x[1]
	// list - linked list , each element has the address of the next one  ; we cannot do list[10]
	
	DynamicArray arr(3);
	DynamicArray arr2;

	//cout << arr.count << " " << arr2.count << " "<<DynamicArray::count << endl;
	cout << DynamicArray::getCount()<<" "<<arr.getCount() << endl;

	assert(arr.getLength() == 0); // we don t have any elemenents in the array
	arr.append(10);
	assert(arr.getLength() == 1);
	arr.append(11);
	assert(arr.getLength() == 2);
	arr.append(12);
	assert(arr.getLength() == 3);
	
	cout << "The array is: " << endl;
	cout << arr << endl;

	arr = arr + 3;
	arr = arr + 4;
	// arr.operator+(5); // operator+ is a member of the class; does not work with friends
	cout << arr << endl;
	// 
	//cout <<"Making a copy of the array"<<endl;
	// // DynamicArray arr_copy = arr; // copy constructor gets called
	//DynamicArray arr_copy; // default constructor
	////arr = arr; // assignment operator gets called; this = arr , other = arr
	//arr_copy = arr; //  assignment operator gets called because arr_copy already existed
	//
	//cout << std::setw(10) << "arr" << arr<<endl;
	//cout << std::setw(10) << "arr_copy" << arr_copy << endl;

	//cout << "remove first element in copy" << endl;
	//arr_copy.remove(0);

	//cout << std::setw(10)<< "arr" << arr << endl;
	//cout << std::setw(10) << "arr_copy" << arr_copy << endl;

	// we'll solve this problem in the next lecture
	
	return 0;
}

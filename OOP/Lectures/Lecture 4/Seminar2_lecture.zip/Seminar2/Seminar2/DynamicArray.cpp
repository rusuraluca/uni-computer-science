#include "DynamicArray.h"
#include <iostream>
using namespace std;

// init of static
int DynamicArray::count = 0;

DynamicArray::DynamicArray(int capacity) {
	length = 0;
	this->capacity = capacity;
	data = new int[capacity]();// () - elems get initialized to 0	
	// count how many objects i created
	count++;
}

DynamicArray::~DynamicArray() {
	//free the allocated memory
	delete[] data;
}

DynamicArray& DynamicArray::operator=(const DynamicArray& other) {
	
	if (this != &other) { // self assignment check
		// deep copy of other
		length = other.length;
		capacity = other.capacity;

		delete[] this->data;
		// !! data 
		// data = other.data; NOO! this is shallow copy
		// deep copy of data
		data = new int[other.capacity]();
		for (unsigned int i = 0; i < length; i++)
			data[i] = other.data[i];
	}
	return *this; // the type of this is DynamicArray* -> dereferencing
}

DynamicArray::DynamicArray(const DynamicArray& other) {
	// deep copy of other
	length = other.length;
	capacity = other.capacity;

	// !! data 
	// data = other.data; NOO! this is shallow copy
	// deep copy of data
	data = new int[other.capacity]();
	for (unsigned int i = 0; i < length; i++)
		data[i] = other.data[i];
}

void DynamicArray::append(int v, bool* err)
{
	// todo 
	// check if the length < capacity
	if (length == capacity) {
		// double the capacity
		resize(capacity*2);
	}
	data[length] = v;
	length++;
}

ostream& operator<<(ostream& s, const DynamicArray& arr) {
	// [1 2 3 4 5 ]
	s << "[";
	for (unsigned int i = 0; i < arr.length; i++) {
		s << arr.data[i] << " ";
	}
	s << "]";
	return s;
}

int DynamicArray::popBack() {
	// delete and return the last element in the array
	// pre array is not empty
	if (length == 0)
		return -1;
	// convention 0 - elements that were not set
	int v = data[length];
	data[length] = 0;
	length--;
	return v;
}

int DynamicArray::remove(unsigned int index)
{
	//  index >= 0 and index < length
	// pre index >=0 and index < length
	if (index >= 0 && index < length) {
		for (unsigned int i = index; i < length - 1; i++)
			data[i] = data[i + 1];
		length--;
	}
	return -1;
}


int DynamicArray::get(unsigned int index, bool* err) {
	
	// pre index >=0 and index < length
	if (index >= 0 && index < length) {
		if(err != nullptr)
			*err = false;
		return data[index];
	}
	if (err != nullptr)
		*err = true;
	return -1;
}

int DynamicArray::getCount()
{
	return count;
}

void DynamicArray::resize(int newCapacity) {
	
	this->capacity = newCapacity;
	// no realloc  in c++
	
	int* newData = new int[newCapacity]();
	// previous elements located in data
	// copy them in newData
	for (unsigned int i = 0; i < length; i++) {
		newData[i] = this->data[i];
	}

	delete[] this->data;
	this->data = newData;
	
}

// DynamicArray:: -> operator+ belongs to the class
//DynamicArray& DynamicArray::operator+(int v) {
//	append(v);
//	return *this;
//}

// DON T put DynamicArray::
DynamicArray& operator+(DynamicArray& arr, int v) {
	// friend has access to private fields
	arr.append(v);
	return arr;
}
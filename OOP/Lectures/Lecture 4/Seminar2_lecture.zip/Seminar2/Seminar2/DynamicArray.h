#pragma once
#include <ostream>
using namespace std;

class DynamicArray
{
public:
	DynamicArray(int capacity=100); // = default parameter
	
	// RULE OF THREE 
	// destructor
	~DynamicArray();

	// copy constructor
	DynamicArray(const DynamicArray& other);

	// assignment operator
	DynamicArray& operator=(const DynamicArray& other);
	// end RULE OF THREE 
	
	// getter for the length
	// inline - it MUST be implemented in the header
	inline unsigned int getLength() const { return length; }

	inline unsigned int getCapacity() const { return capacity; }

	// adds an element at the end
	void append(int v, bool* err = nullptr);

	// remove the element from the end
	// pre: the array is not empty
	int popBack();

	// remove an element from position i
	// index >= 0 and index < length
	int remove(unsigned int index);

	// get the element on a position
	// a[10]
	// index >= 0 and index < length
	// -1 is returned if the index is not valid
	int get(unsigned int index, bool* err = nullptr);

	// print the array
	friend ostream& operator<<(ostream& s, const DynamicArray& arr);

	// operator+ -> append a value to the array
	// opertaor belongs to the class
	// param v -> get appened at the end of the array
	//DynamicArray& operator+(int v); // operator+ -> is a method of DynamicArray

	// second way - friends (the operator does not belong to the class)
	// friend DynamicArray& operator+(DynamicArray& arr, int v);

	// static f(x)
	static int getCount();
private:
	// static -> it belongs to the class
	static int count;
	// Length � how many elements do we have(0)
	unsigned int length;
	//	Capacity � the max number of elements
	unsigned int capacity;
	// data - array itself
	int* data;

	void resize(int newCapacity);
};

DynamicArray& operator+(DynamicArray& arr, int v);
#include <vector>
#include <iostream>
using namespace std;

//since c++14, we can use auto as return type
auto add(int a, int b) {
    return a + b;
}

//  since c++14, trailing return type syntax : adding -> return type at the end of the function declaration
auto subtract(int a, int b) -> int {
    return a - b;
}

// what's nice about auto keyword is that you can nicely left "align" your function declarations
// with auto
auto addTwoNumbersIntAuto(int a, int b);
auto addTwoNumbersDoubleAuto(double a, double b);
auto toStringAuto();

// without auto
int addTwoNumbersInt(int);
double addTwoNumbersDouble(double a, double b);
std::string toString();
// but still, in my personal opinion, you should *Avoid using type inference for function return types*

int main()
{
    auto fVal{ 0.7 }; // 0.7 is a floating point literal, so the compiler will automatically deduce its type, so fVal will have type double
    auto iVal{ 3 + 4 }; // 3 + 4 evaluates to an integer, so iVal will be of type int
    auto cVal{ 'd' }; // cVal will be of type char

    cout << "fVal = " << fVal << endl;
    cout << "iVal = " << iVal << endl;
    cout << "fVal = " << cVal << endl;


    auto sum = add(3, 4);
    cout << "sum= 3 + 4 = " << sum << endl;

    auto diff = subtract(5, 2);
    cout << "dif = 5 - 2 = " << diff << endl;

    // this examples might seem silly, but auto comes in handy when you have types with longer names
    // for example (we'll cover the vector structure n the next lecture, don't worry)
    std::vector<int> myvector = { 1, 2, 3, 4, 5 };

    // iterating through a vector without using auto
    for (std::vector<int>::iterator it = myvector.begin(); it != myvector.end(); ++it)
        std::cout << ' ' << *it;
    cout << endl;
    // iterating through a vector using auto for the iterator type
    for (auto it = myvector.begin(); it != myvector.end(); ++it)
        std::cout << ' ' << *it;
    cout << endl;
    return 0;
}

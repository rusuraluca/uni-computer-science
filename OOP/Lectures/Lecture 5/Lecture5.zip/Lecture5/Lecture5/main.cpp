#include <iostream>
#include <string>
using std::string;
using std::cout;

class Animal {
public:
	Animal();
	Animal(string name) :m_name{ name } {}
	
	virtual // comment/uncomment this line to see the effect of the virtual keyword
		string speak() { return "???"; }
	string getName() { return m_name; }
	string type() { return "Animal"; }

protected:
private:
	string m_name;

};

class Dog : public Animal {
public:
	Dog(string name) : Animal{ name } {}// invoke parent constructor
	string speak() override { return "Woof!"; }
	string type() { return "Dog"; }
};

class Cat : public Animal {
public:
	Cat(string name, string breed = "") : Animal{ name }, m_catBreed{breed} {} // invoke parent constructor, initialize breed
	string speak() { return "Meow!"; }
	string type() { return "Cat"; }
	std::string breed() const { return m_catBreed; }

private:
	std::string m_catBreed;
};

class Duck : public Animal {
public:
	Duck(string name) : Animal{ name } {}// invoke parent constructor
	string speak() { return "Quack!"; }
	string type() { return "Duck"; }
};


void animalReport(Cat c) {
	std::cout << "animalReport(Cat c): animal is a " << c.type() << " called " << c.getName() << " and says: " << c.speak() << '\n';
}

void animalReport(Dog d) {
	std::cout << "animalReport(Dog d): animal is a " << d.type() << " called " << d.getName() << " and says: " << d.speak() << '\n';
}

void animalReport(Animal* animal) {
	std::cout << animal->getName() << " is a " << animal->type() << " called " << animal->getName() << " and says: " << animal->speak() << '\n';
}


void sayHello(Animal animal) // note: base passed by value, not reference
{
	std::cout << "My way of saying hello is " << animal.speak() << '\n';
}

void objectSlicingExample() {
	Cat* cat{ new Cat{"Minou"} };
	Animal* animal{ cat };

	std::cout << animal->getName() << " is a " << animal->type() << " called " << animal->getName() << " and says: " << animal->speak() << '\n';


	Cat catS{ "Pinkie" };
	Animal animalS{ catS };
	std::cout << animalS.getName() << " is a " << animalS.type() << " called " << animalS.getName() << " and says: " << animalS.speak() << '\n';

	sayHello(animalS);
	sayHello(*animal);
}

Animal* getAnimal(bool bGetCat)
{
    if (bGetCat)
        return new Cat("Lara", "Maine Coon");
    else
        return new Animal("No name");
}

void castingExample() {
	Animal* animalCat = getAnimal(true);
	Animal* animal = getAnimal(false);
	//    std::cout << "The breed of the cat is: " << b->catBreed() << '\n';
	Cat* animalCatToCat = dynamic_cast<Cat*>(animalCat); // use dynamic cast to convert base pointer into derived pointer
	Cat* animalToCat = dynamic_cast<Cat*>(animal);


	if (animalCatToCat) // always check for nullptr
		std::cout << "The breed of the cat is: " << animalCatToCat->breed() << '\n';

	if (animalToCat) {
		std::cout << "The breed of the cat is: " << animalCatToCat->breed() << '\n';
	}
	else {
		std::cout << "animalToCat is nullptr " << std::endl;
	}

	getchar();

	Cat* animalCatToCatStatic = static_cast<Cat*>(animalCat); // no runtime type checking; static_cast is faster, but more dangerous
	std::cout << "The breed of the cat is: " << animalCatToCatStatic->breed() << '\n';
	Cat* animalToCatStatic = static_cast<Cat*>(animal); // undefined behaviour
	//std::cout << "The breed of the cat is: " << animalToCatStatic->breed() << '\n';
	getchar();

}

int main()
{
	Animal animal{ "Generic animal" };
	Cat tom{ "Tom" };
	Cat thunder{ "Tunder" };
	Cat garfield{ "Garfield" };
	Dog pluto{ "Pluto" };
	Dog spike{ "Spike" };

	std::cout << tom.getName() << " is a " << tom.type() << " and says: " << tom.speak() << '\n';
	std::cout << pluto.getName() << " is a " << pluto.type() << " and says: " << pluto.speak() << '\n';

	// These are all legal!
	Animal& rCat{ tom };
	Animal* pCat{ &tom };
	Animal aCat = tom;


	std::cout << "rCat is a " << rCat.type() << " called " << rCat.getName() << " and says: " << rCat.speak() << '\n';
	std::cout << "pCat is a " << pCat->type() << " called " << pCat->getName() << " and has value " << pCat->speak() << '\n';
	std::cout << "cat is a " << aCat.type() << " called " << aCat.getName() << " and says: " << aCat.speak() << '\n';


	// why would this be useful?
	// 1.
	animalReport(tom);
	animalReport(pluto);
	animalReport(&tom);
	animalReport(&pluto);


	// 2.
	Cat cats[]{ tom, thunder, garfield };
	Dog dogs[]{ pluto, spike };

	for (int idx = 0; idx < 3; idx++) {
		std::cout << cats[idx].getName() << " says " << cats[idx].speak() << '\n';
	}
	for (int idx = 0; idx < 2; idx++) {
		std::cout << dogs[idx].getName() << " says " << dogs[idx].speak() << '\n';
	}


	// Set up an array of pointers to animals, and set those pointers to our Cat and Dog objects
	Animal* animals[]{ &tom, &thunder, &garfield, &pluto, &spike, };
	for (int idx = 0; idx < 5; idx++) {
		std::cout << animals[idx]->getName() << " says " << animals[idx]->speak() << '\n';
	}

	getchar();
	// object slicing example
	objectSlicingExample();
	getchar();
	// casting example
	castingExample();
	return 0;
}

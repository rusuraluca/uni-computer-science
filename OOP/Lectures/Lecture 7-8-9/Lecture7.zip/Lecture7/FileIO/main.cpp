#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

void testRead()
{
    ifstream f("Students.txt");
    vector<string> names;
    string input;
    if (!f.is_open()){
        std::cerr<<"Unable to open file\n";
        return;
    }
    while (!f.eof())
    {
        f >> input;
        names.push_back(input);
    }

    f.close();

    for(auto name: names){
        cout<<"Student name: "<<name<<'\n';
    }
    cout<<"."<<endl;
    // names will contain the last name (David) twice
}

void testReadCorrected()
{
    ifstream f("Students.txt");
    vector<string> names;
    string input;
    if (!f.is_open())
        return;
    while (f >> input)
    {
        names.push_back(input);
    }
    for(auto name: names){
        cout<<"Student name: "<<name<<'\n';
    }
    cout<<"."<<endl;
}

int main(){
    
    testRead();
    testReadCorrected();
    return 0;
}

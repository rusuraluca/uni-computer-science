#include <array>
#include <string>
#include <vector>
#include <iostream>
#include <functional>

int main(){
    //[] : capture clause
    // (int a) : params
    // -> trailing return syntax (optional)
    // {};: lambda body
    []() {}; // this is a lambda with no captures, no parameters, and no return type

    std::array<std::string, 7> lectures{ "object oriented programming", "math I", "image processing", "functional programming",
                                         "computer programming", "math II", "sport"};

    // example 1
    // find all lectures containing "programming"
    auto found{ std::find_if(lectures.begin(), lectures.end(),
                             [](std::string str) -> bool // lambda, no capture clause, return type not specified
        {
            return str.find("gegerg") != std::string::npos;
        }) };


    if (found == lectures.end())
    {
        std::cout << "No lectures containing programming\n";
    }
    else
    {
        std::cout << "First lecture containing 'programming': " << *found << '\n';
    }
    getchar();

    // use a lambda as a lambda variable. sometimes improves readability
    std::vector<int> digits{0, 2, 4, 6, 8, 1, 3, 5, 7, 9};
    auto isEven{[](int i){return i%2 == 0;}};
    //std::function<bool(int)> isEven{[](int i){return i%2 == 0;}};
    // bool (*isEven)(int){[](int i){return i%2 == 0;}};
    bool allAreEven = std::all_of(digits.begin(), digits.begin() + 3, isEven); // all_of: Test condition on all elements in range specified as a paramter
    if(allAreEven){
        std::cout<<"All digits in the vector are even"<<std::endl;
    }else{
        std::cout<<"Not all digits in the vector are even"<<std::endl;
    }

    getchar();
    // captures
    // find all lectures containing a give string
    std::string myString = "math";
    int i = 0;
    auto foundWithStr{ std::find_if(lectures.begin(), lectures.end(),
                                    [myString,i](std::string str) mutable -> bool
        {
            myString += "I";
            i = 0;
            return str.find(myString) != std::string::npos;
        }) };


    if (foundWithStr == lectures.end())
    {
        std::cout << "No lectures containing "<<myString<<"\n";
    }
    else
    {
        std::cout << "First lecture containing "<<myString<<": "<< *foundWithStr << '\n';
    }


    return 0;
}

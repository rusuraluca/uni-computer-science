#include <vector>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <cctype>
#include <cstdint>
#include <string>
using namespace std;

// flags example
void flagsExample() {
	std::cout << "Today's temperature at Cluj-Napoca is " << 25 << " degrees Celsius" << '\n';
	std::cout.setf(std::ios::showpos); // turn on the std::ios::showpos flag - show positive sign
	std::cout << "Today's temperature at Cluj-Napoca is " << 25 << " degrees Celsius" << '\n';
	std::cout.unsetf(std::ios::showpos); // turn off the std::ios::showpos flag - don't show positive sign
	std::cout << "Today's temperature at Cluj-Napoca is " << 25 << " degrees Celsius" << '\n';
	std::cout.setf(std::ios::showpos | std::ios::oct); // turn on the std::ios::showpos andstd::ios::oct flag - show positive sign + uppercase display in octal
	std::cout.unsetf(std::ios::dec);
	std::cout << "Today's temperature at Cluj-Napoca is " << 25 << " degrees Celsius" << '\n';
	std::cerr << "Today's temperature at Cluj-Napoca is " << 25 << " degrees Celsius" << '\n';
}

// time example
void timeExample() {
	std::tm t = {};
	std::istringstream ss("2020-April-7 23:12:34");
	ss >> std::get_time(&t, "%Y-%b-%d %H:%M:%S");
	if (ss.fail()) {
		std::cout << "Parse failed\n";
	}
	else {
		std::cout << std::put_time(&t, "%c") << '\n'; // %c writes standard date and time string, e.g. Sun Oct 17 04:41:13 2010 (locale dependent)
	}

	ss.clear();
	ss.str("15:43 12-04-2020");

	ss >> std::get_time(&t, "%H:%M %d-%m-%Y");
	if (ss.fail()) {
		std::cout << "Parse failed\n";
	}
	else {
		std::cout << std::put_time(&t, "%c") << '\n';
		std::cout << std::put_time(&t, "Day: %d from %b %y") << '\n'; // %b month abbreviated format, %y last two digits of the year
	}
}

// void manipulators example
void manipulatorsExamples() {
	// precision flags

	double val = 9876.54321;
	std::cout << std::fixed << '\n'; //Use decimal notation for values
	std::cout << "raw: " << val << '\n';
	std::cout << "precision example: \n";
	std::cout << std::setprecision(2) << val << '\n'; // defined in iomanip
	std::cout << std::setprecision(3) << val << '\n';
	std::cout << std::setprecision(4) << val << '\n';
	std::cout << std::setprecision(7) << val << '\n';
	std::cout << "scientific + precision example: \n";
	std::cout << std::scientific << '\n';
	std::cout << std::setprecision(2) << val << '\n';
	std::cout << std::setprecision(3) << val << '\n';
	std::cout << std::setprecision(4) << val << '\n';
	std::cout << std::setprecision(7) << val << '\n';


	getchar();

	// aligning values
	std::cout.fill('_');
	std::cout << -12345 << '\n'; // print default value with no field width
	std::cout << std::setw(10) << -12345 << '\n'; // print default with field width
	std::cout << std::setw(10) << left << -12345 << '\n'; // print left justified
	std::cout << std::setw(10) << right << -12345 << '\n'; // print right justified
	std::cout << std::setw(10) << internal << -12345 << '\n'; // print internally justified; i.e. left-justifies the sign of the number, and right-justifies the value

	getchar();
	std::cout << std::fixed << '\n';
	std::cout << std::setprecision(2) << val << '\n';
	std::cout.fill(' ');
	std::cout << std::setw(10) << left << "x" << " | "
		<< std::setw(10) << left << "10*x" << " | "
		<< std::setw(10) << left << "x^2/8" << " | " << '\n';


	for (double x = 10; x < 100; x += x * 2) {
		std::cout << std::setw(10) << left << std::setw(10) << x << " | "
			<< std::setw(10) << left << std::setw(10) << 10 * x << " | "
			<< std::setw(10) << left << std::setw(10) << x * x / 8.0 << " | \n";
	}
}


void stringStreamExample() {
	std::stringstream os;

	int iValue{ 12345 };
	double dValue{ 67.89 };
	os << iValue << ' ' << dValue;

	std::string strValue1, strValue2;
	os >> strValue1 >> strValue2;

	std::cout << strValue1 << ' ' << strValue2 << '\n';
}


void basicIO() {
	// extraction operator skips whitespace (blanks, tabs, and newlines)
	char buff[20];
	cin >> std::setw(20) >> buff; // ensure that we don't overflow : setw
	cout << "Buff is: " << buff << endl;
	char ch;
	cout << "Please insert some characters" << endl;
	while (cin >> ch) // read character by character, but it skips whitespacess
		//while(cin.get(ch)) // read character by character, but don't skip whitespaces
	{
		cout << ch;
	}
	cout << "end";

}

void getlineExample() {

	char str[20];
	cin.getline(str, 20);
	cout << "Read line: " << str << endl;
	std::cout << std::cin.gcount() << " characters were read" << endl;

}

void validationName() {
	while (true)
	{
		// Validate name
		std::cout << "Enter your name: ";
		std::string name;
		std::getline(cin, name);

		bool bRejected{ false }; // has name been rejected?

		// examine each character
		for (std::size_t nIndex{ 0 }; nIndex < name.length() && !bRejected; ++nIndex)
		{
			if (!nIndex && !isupper(name[nIndex]))
				bRejected = true;
			// an alpha character, that's fine
			if (std::isalpha(name[nIndex])) // in <cctype>
				continue;

			// a space, that's fine too
			if (name[nIndex] == ' ')
				continue;

			// otherwise reject this input
			bRejected = true;
		}

		// if the input has been accepted, exit the while loop
		if (!bRejected)
			break;
	}

}

void validationAge() {
	int age;

	while (true)
	{
		std::cout << "Enter your age: ";
		std::cin >> age;

		if (std::cin.fail()) // check the fail bit
		{
			std::cin.clear(); // reset the state bits back to goodbit
			std::cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear out the bad input from the stream
			continue; // try again
		}

		std::cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear out any additional input from the stream
		if (std::cin.gcount() > 1) // check how many characters we read
			continue; //if we read more than one additional character, we'll consider this input to be invalid

		if (age <= 0) // make sure nAge is positive
			continue;

		break;
	}

	std::cout << "You entered: " << age << '\n';
}

int main() {
	basicIO();
	getlineExample();
	flagsExample();
	timeExample();
	manipulatorsExamples();
	stringStreamExample();
	validationName();
	validationAge();

	return 0;
}


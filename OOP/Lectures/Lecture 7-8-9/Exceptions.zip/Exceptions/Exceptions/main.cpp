#include <iostream>
using namespace std;


/////////////////////// exception basics

void exceptionsBasic() {

    try {
        throw 1;
        std::cout << "This never prints\n";
    }
    catch (int& e) {
        std::cout << "Caught integer exception: " << e << '\n';
    } /*catch(...){
        std::cout<<"Catch any type of exception.\n";
    }*/
}


/////////////////////// end exception basics


/////////////////////// stack unwinding
void stackUnwindingf4() // called by f3()
{
    std::cout << "Start "<<__FUNCTION__<<"\n";
    std::cout <<__FUNCTION__ <<" throwing exception\n";
    throw -1;
    std::cout << "End "<<__FUNCTION__<<"\n";

}

void stackUnwindingf3() // called by f2()
{
    std::cout << "Start "<<__FUNCTION__<<"\n";
    stackUnwindingf4();
    std::cout << "End "<<__FUNCTION__<<"\n";
}

void stackUnwindingf2() // called by f1()
{
    std::cout << "Start "<<__FUNCTION__<<"\n";
    try
    {
        stackUnwindingf3();
    }
    catch(double)
    {
        std::cerr << __FUNCTION__ <<" caught double exception\n";
    }
    std::cout << "End "<<__FUNCTION__<<"\n";
}

void stackUnwindingf1() // called by main()
{
    std::cout << "Start "<<__FUNCTION__<<"\n";
    try
    {
        stackUnwindingf2();
    }
    catch (int)
    {
        std::cerr << __FUNCTION__ <<" caught int exception\n";
    }
    catch (double)
    {
        std::cerr << __FUNCTION__ <<" caught double exception\n";
    }
    std::cout << "End "<<__FUNCTION__<<"\n";
}


// Compute the square root of a numaber
double mySqrt(double x) noexcept(false)
{
    // tf the parameter is a negative number, this is an error condition
    if (x < 0.0)
        throw "Can not take sqrt of negative number"; // throw exception of type const char*

    return sqrt(x);
}

void stackUnwindingExample() {
        double x;
    std::cout<<"Type a nuber to compute the sqrt for:\n";
    std::cin >> x;

    try
    {
        double d = mySqrt(x);
        std::cout << "The sqrt of " << x << " is " << d << '\n';
    }
    catch (const char* exception) // catch exceptions of type const char*
    {
        std::cerr << "Error: " << exception << std::endl;
    }

    getchar();
    std::cout<<"\n----------------------------\n";
    stackUnwindingf1();
}
/////////////////////// end stack unwinding

/////////////////////// exception with classes

class BaseException
{
public:
    BaseException() {}
};

class DerivedException: public BaseException
{
public:
    DerivedException() {}
};

void f1(){
    std::cerr<<__FUNCTION__<< " throws a DerviedException\n";
    throw DerivedException();
}

void f2(){
    try {
        f1();
    } catch (BaseException &b) {
        std::cerr<<__FUNCTION__<<" caught a base exception, logs it, and rethrows it \n";
        throw b;
    }
}

void f3(){
    try {
        f2();
    }catch (DerivedException &b) {
        std::cerr<<__FUNCTION__<<" caught a derived exception \n";
    }
    catch (BaseException &b) {
        std::cerr<<__FUNCTION__<<" caught a base exception \n";
    }
}

void exceptionClasses() {
          f3();
        try
        {
            throw DerivedException();
        }
        catch (BaseException &base)
        {
            cerr << "caught Base\n";
        }
        catch (DerivedException &derived)
        {
            cerr << "caught Derived\n";
        }

}

/////////////////////// end exception with classes


//////////////////////  exceptions in constructor
class ClassMember
{
public:
    ClassMember()
    {
        std::cerr << "ClassMember allocated some resources\n";
    }

    ~ClassMember()
    {
        std::cerr << "ClassMember cleaned up\n";
    }
};

class ContructorFails
{
private:
    int m_positiveInt;
    ClassMember m_member;

public:
    ContructorFails(int x) : m_positiveInt(x)
    {
        if (x <= 0)
            throw 1;
    }

    ~ContructorFails()
    {
        std::cerr << "~ContructorFails\n";
    }
};


void exceptionsConstructor() {
     try {
        ContructorFails(-2);
    } catch (int &e) {
        std::cerr<<"Exception caught! "; // the destructor of ContructorFails is not called, but its members are deallocated!
    }

}

////////////////////// end exceptions in constructor 
int main() {
    exceptionsBasic();
    stackUnwindingExample();
    exceptionClasses();
    exceptionsConstructor();
    return 0;
}

Rails.application.routes.draw do
  namespace :api do
    resources :stocks
    resources :users do
      resources :portfolio
    end
  end
end

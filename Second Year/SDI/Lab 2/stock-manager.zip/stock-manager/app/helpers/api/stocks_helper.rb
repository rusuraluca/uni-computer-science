module Api::StocksHelper
end

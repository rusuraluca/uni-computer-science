class Api::Portfolio < ApplicationRecord
  belongs_to :api_user
end

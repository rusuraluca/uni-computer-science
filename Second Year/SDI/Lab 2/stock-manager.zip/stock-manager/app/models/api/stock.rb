class Api::Stock < ApplicationRecord
end

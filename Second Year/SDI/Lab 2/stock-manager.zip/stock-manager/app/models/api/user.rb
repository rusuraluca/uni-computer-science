class Api::User < ApplicationRecord
  has_many :api_portfolios
end

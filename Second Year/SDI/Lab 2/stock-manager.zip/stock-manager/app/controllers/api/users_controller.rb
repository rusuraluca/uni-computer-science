class Api::UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]

  # GET api/users
  def index
    @users = Api::User.all
    render json: @users
  end

  # GET api/users/:id
  def show
    render json: @user
  end


  def new
    @user = Api::User.new
  end

  # POST api/users
  def create
    @user = Api::User.create(user_params)

    if @user.save
      render json: @user, status: :created, location: @user
    else
      render json: @user.errors, status: :unprocessable_entity
    end
  end


  def edit
  end

  # PATCH/PUT api/users/:id
  def update
    if @user.update(user_params)
      render json: @user
    else
      render json: @user.errors, status: :unprocessable_entity
    end
  end

  # DELETE api/users/:id
  def destroy
    @user.destroy
    render json: @user
  end


  private
  # using callbacks to share common setup or constraints between actions
  def set_user
    @user = Api::User.find(params[:id])
  end

  # using strong parameters
  # only allow a trusted parameter "white list" through, filters params
  def user_params
    params.require(:user).permit(:first_name, :last_name, :email, :password, :address, :birthday)
  end

  def portfolio_params
    params.require(:portfolio).permit(:name, :active, :industry, :value, :currency)
  end
end
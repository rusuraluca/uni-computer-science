require "test_helper"

class Api::StockTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

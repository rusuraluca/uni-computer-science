class CreateApiStocks < ActiveRecord::Migration[7.0]
  def change
    create_table :api_stocks do |t|
      t.string :name, null: false
      t.float :current_price, null: false
      t.float :min_price, null: false
      t.float :max_price, null: false
      t.string :industry
      t.timestamps
    end
  end
end

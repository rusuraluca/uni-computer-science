# Lab 1 solution
**Programming Language**: 
Ruby
- interpreted scripting language for quick and easy object-oriented programming

**Framework**: Ruby on Rails
- designed to make programming web applications easier by making assumptions about what every developer needs to get started
- allows you to write less code while accomplishing more than many other languages and frameworks
- libraries: there’s a gem for just about anything you can think of, they are all publicly available at RubyGems
- folows the MVC Architecture
    - Models
        - ruby classes that handle the business logic by talking with the database to validate data
    - Views
        - templates (typically formed of a mix of HTML and Ruby code) that render the data from your models and handle logic for presentation that end users see and interact with
    - Controller
        - the middleman between the model and the view controlling the flow of the application
        - handle the requests, initiates changes to the model, redirects, etc.     
- guiding principles:
    - Don't Repeat Yourself:    
        - by not writing the same information over and over again, our code is more maintainable, more extensible, and less buggy
    - Convention Over Configuration
        - Rails has opinions about the best way to do many things in a web application, and defaults to this set of conventions, rather than require that you specify minutiae through endless configuration files     

- model is a Ruby class that is used to represent data and that can interact with the application's database through a feature of Rails called Active Record
  - model names are singular, because an instantiated model represents a single data record
  - Active Record automatically defines model attributes for every table column, so you don't have to declare those attributes in your model file
- routes are rules written in a Ruby DSL (Domain-Specific Language)
- controllers are Ruby classes, and their public methods are actions
- views are templates, usually written in a mixture of HTML and Ruby
- when an action does not explicitly render a view (or otherwise trigger an HTTP response), 
  Rails will automatically render a view that matches the name of the controller and action
- a route parameter captures a segment of the request's path, and puts that value into the params Hash, which is accessible by the controller action
- Autoloading:
    - Rails applications do not use require to load application code,
    - application classes and modules are available everywhere, you do not need and should not load anything under app with require  
    - you only need require calls for two use cases:
        - to load files under the lib directory
        - to load gem dependencies that have require: false in the Gemfile
- migrations are used to alter the structure of an application's database
    - in Rails applications, migrations are written in Ruby so that they can be database-agnostic        

----
Prerequisites
```
$ ruby --version
ruby 3.0.0
$ rails --version
rails 7.0.4.2
```

Create a new Rails application
```
$ rails new stock-app
```
- will create a Rails application called Stock-app in a stock-app directory 
  and install the `gem dependencies` that are already mentioned in `Gemfile` using `bundle install`

Starting up the Web Server
```
$ rails s
or
$ rails start
```
- to see your application in action, open a browser window and navigate to `http://localhost:3000`

Adding the routes 
- since we are going to use all CRUD operations, I used the shortcut Rails provides:
```
  namespace :api do
    # whenever we have such a combination of routes, controller actions, and views that work together to perform CRUD operations on an entity, we call that entity a resource
    # Rails provides a routes method named resources that maps all of the conventional routes for a collection of resources, such as stocks
    # this method also sets up URL and path helper methods that we can use to keep our code from depending on a specific route configuration
    resources :stocks
  end
```
- otherwise:
```
 get "/api/stocks", to: "api/stocks#index"
 # route above declares that GET /api/stocks requests are mapped to the index action of Api::StocksController
```

Entity:
Stock

name: string, NOT_NULL

current_price: float, NOT_NULL

min_price: float, NOT_NULL

max_price: float, NOT_NULL

industry: string

- call to create_table specifies how the stock table should be constructed
- by default, the create_table method adds an id column as an auto-incrementing primary key;
  so the first record in the table will have an id of 1, the next record will have an id of 2, and so on
- t.timestamps this method defines two additional columns named created_at and updated_at, Rails will manage these for us, setting the values when we create or update a model object
```
class CreateApiStocks < ActiveRecord::Migration[7.0]
  def change
    create_table :api_stocks do |t|
      t.string :name, null: false
      t.float :current_price, null: false
      t.float :min_price, null: false
      t.float :max_price, null: false
      t.string :industry
      t.timestamps
    end
  end
end
```

CRUDit Where CRUDit Is Due:
Stocks Controller
```ruby
  # filters are methods that are run "before", "after" or "around" a controller action
  # filters are inherited, so if you set a filter on ApplicationController, it will be run on every controller in your application
  # "before" filters are registered via before_action, they may halt the request cycle
  before_action :set_stock, only: [:show, :edit, :update, :destroy]


  # GET /stocks
  def index
    # when we want to fetch all articles from the database, we can call all on the model
    # this method returns an ActiveRecord::Relation object, which is like a super-powered array
    @stocks = Api::Stock.all
    render json: @stocks
  end

  # GET /stocks/:id
  def show
    render json: @stock
  end

  # typically, in web applications, creating a new resource is a multi-step process:
  # first, the user requests a form to fill out
  # then, the user submits the form
  # if there are no errors, then the resource is created and some kind of confirmation is displayed
  # else, the form is redisplayed with error messages, and the process is repeated
  # in a Rails application, these steps are conventionally handled by a controller's new and create actions


  # instantiates a new stock, but does not save it
  # this stock will be used in the view when building the form
  # by default, the new action will render app/views/api/stocks/new.html.erb, which we will create next
  def new
    @stock = Api::Stock.new
  end

  # POST /stocks
  # instantiates a new stock with values and attempts to save it
  # if the stock is saved successfully, the action redirects the browser to the stock's page
  # else, the action redisplays the form by rendering app/views/articles/new.html.erb with status code 422 Unprocessable Entity
  def create
    @stock = Api::Stock.new(stock_params)

    if @stock.save
      # redirect_to will cause the browser to make a new request,
      # whereas render renders the specified view for the current request
      # it is important to use redirect_to after mutating the database or application state,
      # otherwise, if the user refreshes the page, the browser will make the same request, and the mutation will be repeated
      # redirect_to @stock
      render json: @stock, status: :created, location: @stock
    else
      render json: @stock.errors, status: :unprocessable_entity
    end
  end

  # edit action fetches the stock from the database,
  # and stores it in @stock so that it can be used when building the form
  # by default, the edit action will render app/views/articles/edit.html.erb
  def edit
  end

  # PATCH/PUT /stocks/:id
  def update
    if @stock.update(stock_params)
      render json: @stock
    else
      render json: @stock.errors, status: :unprocessable_entity
    end
  end

  # DELETE /stocks/:id
  def destroy
    @stock.destroy
    render json: @stock
  end


  private
  # using callbacks to share common setup or constraints between actions
  def set_stock
    # when we want to fetch a stock from the database, we can call find on the model and pass the id as an argument
    @stock = Api::Stock.find(params[:id])
  end

  # using strong parameters
  # only allow a trusted parameter "white list" through, filters params
  def stock_params
    params.require(:stock).permit(:name, :current_price, :min_price, :max_price, :industry)
  end
```

# Lab 1 assignment

**Points**: 1

**Deadline**: Week 2

**Last chance deadline and penalties**: Week 4, -0.3 points / week delayed

----

Choose any programming language and a **backend** framework and setup a development environment in it. 
Create an application with CRUD functionalities for a single entity of your choice. The entity should have at least 5 attributes, not counting the ID. You do not need any validations.

Remarks:
- Your application should either expose a REST API (like Django REST Framework, Flask) or a webpage that can be accessed in the browser (like Django)
- Console apps are **not** allowed
- Frontend frameworks / libraries (React, Angular) are **not** allowed
- You should be able to explain basic things about your framework of choice (where routes are defined, how the models are handled etc.) 
- You will also be marked on good coding practices and design principles, as they have been taught in Fundamentals of Programming and Object Oriented Programming and as they apply to your choice of framework

Suggestions:
- You can probably find libraries in your favorite language that help you build Web applications and REST APIs
- I suggest you make a REST API, as that will become mandatory later on anyway
- Java has Spring, Python has Django, C# has WebApi etc. The keywords to search for are your language + rest api
- Make sure you get comfortable with reading your choice's documentation and that you pick something with an active community, as you will be spending a lot of time studying stuff on your own


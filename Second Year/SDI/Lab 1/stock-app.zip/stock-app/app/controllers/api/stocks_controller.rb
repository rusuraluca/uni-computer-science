class Api::StocksController < ApplicationController
  before_action :set_stock, only: [:show, :edit, :update, :destroy]

  # GET /stocks
  def index
    @stocks = Api::Stock.all
    render json: @stocks
  end

  # GET /stocks/:id
  def show
    render json: @stock
  end


  def new
    @stock = Api::Stock.new
  end

  # POST /stocks
  def create
    @stock = Api::Stock.create(stock_params)

    if @stock.save
      render json: @stock, status: :created, location: @stock
    else
      render json: @stock.errors, status: :unprocessable_entity
    end
  end


  def edit
  end

  # PATCH/PUT /stocks/:id
  def update
    if @stock.update(stock_params)
      render json: @stock
    else
      render json: @stock.errors, status: :unprocessable_entity
    end
  end

  # DELETE /stocks/:id
  def destroy
    @stock.destroy
    render json: @stock
  end


  private
  # using callbacks to share common setup or constraints between actions
  def set_stock
    @stock = Api::Stock.find(params[:id])
  end

  # using strong parameters
  # only allow a trusted parameter "white list" through, filters params
  def stock_params
    params.require(:stock).permit(:name, :current_price, :min_price, :max_price, :industry)
  end
end

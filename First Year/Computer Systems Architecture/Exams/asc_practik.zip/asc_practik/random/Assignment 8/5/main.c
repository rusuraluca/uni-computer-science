#include <stdio.h>

int QuickMaths(int a, int b, int c);

int main()
{
	int a, b, c, sum;

	printf("a= ");          
	scanf_s("%d", &a);
	printf("b= ");
	scanf_s("%d", &b);
	printf("c= ");
	scanf_s("%d", &c);
	sum = QuickMaths(a, b, c);
	printf("The result of a + b - c is : %d", sum);
	

	return 0;

}
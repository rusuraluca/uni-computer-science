#pragma once
#include <string>
#include <ostream>
class Vector2D
{

public:
	// static data member
	static int getNumberOfInstances();

	/// default constructor; we default all variables
	Vector2D(double x = 0, double y = 0);

	/// copy constructor
	Vector2D(const Vector2D& v);

	/// destructor
	~Vector2D();

	// getters; inline methods, they are defined in the header
	inline double getXCoordinate() {
		m_x = 100;
		return this->m_x;
	}
	double getXCoordinate() const {
		return this->m_x;
	}
	double getYCoordinate() { return this->m_y; }

	void setXCoordinate(double xCoordinate) { this->m_x = xCoordinate; }
	void setYCoordinate(double y) { m_y = y; }
	/**
		Adds the given 2D vector to the current 2D vector.
		@param v - Vector2D. v is added to the current 2D vector
	*/
	void add(const Vector2D& v);

	/**
		Subtract the given 2D vector from the current 2D vector.
		@param v - Vector2D. v is subtracted from the current 2D vector.
	*/
	void subtract(Vector2D v);

	/**
		Rotates the current 2D vector.
		@param angle -  rotation angle in radians;  the current 2D vector is rotated with the given angle.

	*/
	void rotate(double angle);

	std::string toString();

	/**
		Multiplies the current 2D vector with a scalar value.
		@param scalarValue - scalar multipler; the current 2D vector is multiplied by the given value.
	*/
	void multiplyByScalar(double scalarValue);


	/**
		Overloading the + operator to add 2 2D vectors.
		Input: v - Vector2D
		Output: a 2D vector representing the sum of the current 2D vector and the parameter v.
	*/
	Vector2D operator+(const Vector2D& v);

	/**
		Overloading the * operator to multiply a 2D vector with a scalar value.
		@param scalarValue - scalar multiplier
		@return a 2D vector representing the product of the current 2D vector and the given scalar value.
	*/
	Vector2D operator*(double scalarValue);

	// assignment operator
	Vector2D& operator=(const Vector2D& v);

	// friend function
	friend std::ostream& operator<<(std::ostream& os, const Vector2D& v);
private:
	// private fields
	double m_x;
	double m_y;
	/// static variable to store the number of instances of the class
	static int numberOfInstances;
};

// non-member function
Vector2D operator*(double scalarValue, const Vector2D& v);


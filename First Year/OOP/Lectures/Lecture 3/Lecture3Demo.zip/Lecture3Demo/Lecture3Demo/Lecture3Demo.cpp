#include "Vector2D.h"
#include <iostream>
#include <string>
#include <Windows.h>

#define PI 3.14159265
#include <cmath>
#include <iostream>

int main()
{
	system("color f4");

	Vector2D v1{ -1, 1 };

	std::cout << "\nThere are " << Vector2D::getNumberOfInstances() << " objects of class Vector2D." << std::endl;


	Vector2D v2{ 2, 3 };
	std::cout << "\nThere are " << Vector2D::getNumberOfInstances() << " objects of class Vector2D." << std::endl;


	Vector2D v3 = v1 + v2;	// <=> Vector2D v3 = v1.operator+(v2);
	std::cout << "\nThere are " << Vector2D::getNumberOfInstances() << " objects of class Vector2D." << std::endl;


	v1.operator+(v2);

	Vector2D v4 = v1 * 3;	// <=> Vector2D v3 = v1.operator*(3);

	std::cout << "\nThere are " << Vector2D::getNumberOfInstances() << " objects of class Vector2D." << std::endl;

	Vector2D v5 = 3 * v1;	// will this work? Why/why not?

	std::cout << "v3 is: " << v3.toString();
	std::cout << "v4 is: " << v4.toString();
	std::cout << "v5 is: " << v5.toString();

	Vector2D v6{};
	v6 = v4;			// assignment operator called
	v6 = v2 = v1;		// assignment operator called twice <=> v6.operator=(v2.operator=(v1))

	Vector2D v7 = v1;	// copy constructor is called (a new object is created and data is copied into it)
	Vector2D v8{}; // default constructor
	v8 = v2;			// assignment operator is called (the object already exists, data is copied into it)

	std::cout << "v8 is: " << v8 << std::endl;
	system("pause");
	return 0;
}
#include "Vector2D.h"
#include <cmath>
#include <sstream>
#include <iostream>

// initialize the static member
int Vector2D::numberOfInstances = 0;

int Vector2D::getNumberOfInstances() 
{
	return numberOfInstances;
}

// member initalization xCoordinate(x), yCoordinate(y) 
Vector2D::Vector2D(double x, double y) : m_x(x), m_y(y) 
{ 
	numberOfInstances++; 
}

Vector2D::Vector2D(const Vector2D& v)
{
	this->m_x = v.m_x;
	this->m_y = v.m_y;

	numberOfInstances++;
}

Vector2D::~Vector2D() 
{
	//std::cout << "Destructor";

	//numberOfInstances--;
}

void Vector2D::add(const Vector2D& v)
{
	this->m_x += v.m_x;
	this->m_y += v.m_y;
}

void Vector2D::subtract(Vector2D v)
{
	this->m_x -= v.m_x;
	this->m_y -= v.m_y;
}

void Vector2D::rotate(double angle)
{
	this->m_x = this->m_x * cos(angle) - this->m_y * sin(angle);
	this->m_y = this->m_x * sin(angle) + this->m_y * cos(angle);
}

void Vector2D::multiplyByScalar(double scalarValue)
{
	this->m_x *= scalarValue;
	this->m_y *= scalarValue;
}

std::string Vector2D::toString()
{
	std::stringstream txt;
	txt << "(" << this->m_x << ", " << this->m_y << ")" << std::endl;
	return txt.str();
}

Vector2D Vector2D::operator+(const Vector2D& v)
{
	Vector2D res(this->m_x, this->m_y);
	res.add(v);
	return res;
}

Vector2D Vector2D::operator*(double scalarValue)
{
	Vector2D res(*this);
	res.multiplyByScalar(scalarValue);
	return res;
}

Vector2D& Vector2D::operator=(const Vector2D& v)
{
	this->m_x = v.m_x;
	this->m_y = v.m_y;
	return *this;
}

// non-member function
Vector2D operator*(double scalarValue, const Vector2D& v)
{
	Vector2D res(v);
	res.multiplyByScalar(scalarValue);
	return res;
}

std::ostream& operator<<(std::ostream& os, const Vector2D& v)
{
	os << "(" << v.m_x << ", " << v.m_y << ") ";
	return os;
}





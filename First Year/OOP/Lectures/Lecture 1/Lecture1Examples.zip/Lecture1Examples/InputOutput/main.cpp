#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

using namespace std;

int main()
{
    system("color f4");
    int nr = 5;
    double nrf = 3.14;
    char c = 's';
    char str[] = "abc";

    printf("Print an integer: nr=%d \n", nr);
    printf("Print a floating point %0.2f \n", nrf);
    printf("Print a character: %c \n", c);
    printf("Print a string %s\n", str);


    printf("Input a new value for nrf: ");
    scanf("%lf", &nrf); // read a double

    printf("nrf is now %.2f.\n", nrf);

    char name[10];
    int age = 0;

    printf("Input a name and an age: ");
    scanf("%s %d", name, &age);

    printf("Name: %s, age: %d.\n", name, age);

    system("pause");

    return 0;
}

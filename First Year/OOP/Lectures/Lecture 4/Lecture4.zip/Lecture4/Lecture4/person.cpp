#include "person.h"


Person::Person(long long id, std::string name, std::string address) :m_id{id}
{
    std::cout<<"---- person constructor\n";
    m_name = name;
    m_address = address;
}

Person::~Person()
{
    std::cout<<"---- person destructor\n";
}

void Person::displayProfile()
{
    std::cout<<"Hello! I'm "<<m_name<<"; my id is "<< m_id<<" and I live at the following address: "<<m_address<<"\n";
}

void Person::changeAddress(std::string newAddress)
{
    m_address = newAddress;
}

ostream& operator<<(ostream& os, const Person& p)
{
    os << "Hello! I'm " << p.m_name << "; my id is " << p.m_id << " and I live at the following address: " << p.m_address << "\n";
    return os;
}

#include "person.h"
#include "student.h"
#include <iostream>
using namespace std;


void displayPerson(Person p)
{
    std::cout<<"------------ display person"<<endl;
    p.displayProfile();
}

void displayStudent(Student s)
{
    std::cout<<"------------ display student"<<endl;
    s.displayProfile();
}

void substitutionPrinciple()
{

    Person person{1278, "Ion Popescu", "Eroilor street"};
    Student student{1278, "John Doe", "Kogalniceanu street", 1, 812};

    displayPerson(person);

    person = student;		// implicit upcast
    displayPerson(student);	// implicit upcast
    displayStudent(student);
    cout << endl;

    // student = person;	// error!
    //showStudent(person); // error !
}



int main(int argc, char *argv[])
{
    Person per{1278, "Ion Popescu", "Eroilor street"};
    per.displayProfile();

    Student st{127868, "John Doe", "Kogalniceanu street", 1, 811};
    
    st.addClass("MATH101");
    st.addClass("CALCULUS102");
    st.addClass("CALCULUS102");
    st.addClass("CP");
    st.addClass("OOP");


    st.displayProfile();
    
    cout << st << endl;

    return 0;
}

#ifndef STUDENT_H
#define STUDENT_H

#include <vector>
#include "person.h"

class Student: public Person
{
public:
    Student(int id, std::string name, std::string address, int group, int m_year);
    ~Student();

    void addClass(std::string newClass);
    void changeGroupNumber(int newGroup);

    void displayProfile();

    friend ostream& operator<<(ostream& os, const Student& s);


private:
    int m_academicYear; //1, 2, 3
    std::vector<std::string> m_classes;
    int m_groupNumber;
};

#endif // STUDENT_H

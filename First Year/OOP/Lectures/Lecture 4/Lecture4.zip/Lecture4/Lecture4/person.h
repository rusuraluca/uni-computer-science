#ifndef PERSON_H
#define PERSON_H

#include <string>
#include <iostream>
#include <ostream>
using namespace std;

class Person
{
public:
    Person(long long id, std::string name, std::string address);
    ~Person();

    void displayProfile();

    friend ostream& operator<<(ostream& os, const Person& p);

    void changeAddress(std::string newAddress);

    inline long long getPersonID() const {
        return m_id;
    }

protected:
    std::string m_name;
    std::string m_address;
private:
    long long m_id;
};

#endif // PERSON_H

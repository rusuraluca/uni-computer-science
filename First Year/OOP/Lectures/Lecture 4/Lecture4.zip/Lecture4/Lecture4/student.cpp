#include "student.h"


Student::Student(int id, std::string name, std::string address, int group, int year):
   Person(id, name, address), // parent constructor invocation
   m_groupNumber{group}  // list initializaion for class member
{
    std::cout<<"---- student constructor\n";
    this->m_academicYear = year; // member initialzation
}

Student::~Student()
{
    std::cout<<"--- student destructor \n";
}

void Student::addClass(std::string newClass)
{
    m_classes.push_back(newClass);
}

void Student::changeGroupNumber(int newGroup)
{
    m_groupNumber = newGroup;
}

void Student::displayProfile()
{

    Person::displayProfile(); // duty delegation, call displayProfile from base class
    std::cout<<"I'm a student! I'm from group "<<m_groupNumber<<" and in year "<<m_academicYear<<"\nI've taken the following classes: ";
    for(unsigned int i = 0; i < m_classes.size(); i++){
        std::cout<<m_classes.at(i)<< ((i < m_classes.size() - 1) ? ", ": "") ;

    }
    std::cout<<".\n";

}

ostream& operator<<(ostream& os, const Student& s)
{
    os << static_cast<const Person&>(s);
    std::cout << "I'm a student! I'm from group " << s.m_groupNumber << " and in year " << s.m_academicYear << "\nI've taken the following classes: ";
    for (unsigned int i = 0; i < s.m_classes.size(); i++) {
        std::cout << s.m_classes.at(i) << ((i < s.m_classes.size() - 1) ? ", " : "");

    }
    std::cout << ".\n";
    return os;
}

#include <string>
#include <iostream>
using namespace std;

int a = 10; // a - global variable; DON T USE GLOBAL VARIABLES! :)


namespace my_namespace {
    int a = 20; //  a - variable defined in my_namespace

    void function1() { // declared and defined in my_namespace
        std::cout << "I'm function1 from my_namespace" << std::endl;
    }
    void function2(); // declared in my_namespace but defined outside the namespace

    class string {
    public:
        void print() {
            cout << "example namespace string"<<endl;
        }
    private:
        char chars[100];
        unsigned int lenght;
    };
}

void my_namespace::function2() {
    a = 70;
    my_namespace::a = -1;
    std::cout << "I'm function 2, declared in my_namespace but defined outside the namespace" << std::endl;
    std::cout << "\ta = " << a << std::endl;
    std::cout << "\tmy_namespace::a = " << my_namespace::a << std::endl;
}

using my_namespace::function1;

int main()
{
    my_namespace::string s;
    s.print();
    std::cout << "global variable a is " << a << std::endl;
    std::cout << "variable a defined in namespace my_namespace is " << my_namespace::a << std::endl;
    function1();
    my_namespace::function2();
    std::cout << "global variable a is " << a << std::endl;
    std::cout << "variable a defined in namespace my_namespace is " << my_namespace::a << std::endl;

    return 0;
}

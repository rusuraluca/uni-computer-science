#include <iostream>
#include <string>
using std::string;
using std::cout;

class Animal {
public:
	Animal() = default;
	Animal(string name) :m_name{ name } {}
	virtual string speak() { return "???"; }
	string getName() { return m_name; }
	string type() { return "Animal"; }

protected:
private:
	string m_name;

};

class Dog : public Animal {
public:
	Dog(string name) : Animal{ name } {}// invoke parent constructor
	string speak() { return "Woof!"; }
	string type() { return "Dog"; }
};

class Cat : public Animal {
public:
	Cat(string name) : Animal{ name } {}// invoke parent constructor
	string speak() { return "Meow!"; }
	string type() { return "Cat"; }
};

class Duck : public Animal {
public:
	Duck(string name) : Animal{ name } {}// invoke parent constructor
	string speak() { return "Quack!"; }
	string type() { return "Duck"; }
};


void animalReport(Cat c) {
	std::cout << "animalReport(Cat c): animal is a " << c.type() << " called " << c.getName() << " and says: " << c.speak() << '\n';
}

void animalReport(Dog d) {
	std::cout << "animalReport(Dog d): animal is a " << d.type() << " called " << d.getName() << " and says: " << d.speak() << '\n';
}

void animalReport(Animal* animal) {
	std::cout << animal->getName() << " is a " << animal->type() << " called " << animal->getName() << " and says: " << animal->speak() << '\n';
}

void sayHello(Animal animal) // note: base passed by value, not reference
{
	std::cout << "My way of saying hello is " << animal.speak() << '\n';
}

void objectSlicing() {
	Cat* cat = new Cat{ "Minou" };
	Animal* animal{ cat };

	std::cout << animal->getName() << " is a " << animal->type() << " called " << animal->getName() << " and says: " << animal->speak() << '\n';
	getchar();
	Cat catS{ "Pinkie" };
	
	
	Animal animalS{ catS };
	std::cout << animalS.getName() << " is a " << animalS.type() << " called " << animalS.getName() << " and says: " << animalS.speak() << '\n';


	sayHello(animalS);
	getchar();
	sayHello(*animal);

	delete cat;
}

int main()
{
	Animal animal{ "Generic animal" };
	Cat tom{ "Tom" };
	Cat thunder{ "Tunder" };
	Cat garfield{ "Garfield" };
	Dog pluto{ "Pluto" };
	Dog spike{ "Spike" };

	std::cout << tom.getName() << " is a " << tom.type() << " and says: " << tom.speak() << '\n';
	std::cout << pluto.getName() << " is a " << pluto.type() << " and says: " << pluto.speak() << '\n';
	getchar();
	// These are all legal!
	Animal& rCat{ tom };
	Animal* pCat{ &tom };
	Animal aCat = tom;


	std::cout << "rCat is a " << rCat.type() << " called " << rCat.getName() << " and says: " << rCat.speak() << '\n';
	std::cout << "pCat is a " << pCat->type() << " called " << pCat->getName() << " and has value " << pCat->speak() << '\n';
	std::cout << "cat is a " << aCat.type() << " called " << aCat.getName() << " and says: " << aCat.speak() << '\n';
	getchar();

	// why would this be useful?
	// 1.
	animalReport(tom);
	animalReport(pluto);
	animalReport(&tom);
	animalReport(&pluto);

	getchar();
	// 2.
	Cat cats[]{ tom, thunder, garfield };
	Dog dogs[]{ pluto, spike };

	for (int idx = 0; idx < 3; idx++) {
		std::cout << cats[idx].getName() << " says " << cats[idx].speak() << '\n';
	}
	for (int idx = 0; idx < 2; idx++) {
		std::cout << dogs[idx].getName() << " says " << dogs[idx].speak() << '\n';
	}

	getchar();
	// Set up an array of pointers to animals, and set those pointers to our Cat and Dog objects
	Animal* animals[]{ &tom, &thunder, &garfield, &pluto, &spike, };
	for (int idx = 0; idx < 5; idx++) {
		std::cout << animals[idx]->getName() << " says " << animals[idx]->speak() << '\n';
	}

	// 3.
	getchar();
	objectSlicing();

	return 0;
}

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <crtdbg.h> // _CrtDumpMemoryLeaks();


int main()
{
	system("color f4");

	//allocate memory on the heap for an int
	int* p = (int*)malloc(sizeof(int));
	*p = 7;
	printf("Value at address p: %d,\n", *p);
	
	//allocate space for n ints (array) - this cannot be made statically (try int arr[n])
	int n = 0;
	printf("Input the length for your array: ");
	scanf("%d", &n);
	int* arr = (int*)malloc(n * sizeof(int));
	arr[0] = 0;
	arr[1] = 1;

	printf("Second element of the array: %d. \n", arr[1]);

	//dealocate
	free(arr);


	p = NULL;
	for (int i = 0; i < 10; i++)
	{
		p = (int*)malloc(sizeof(int));
		//allocate memory for an int on the heap
		*p = i * 2;
		printf("Value of p: %d.\n", *p);
	}
	free(p); //deallocate memory
			

	system("pause");

	return 0;
}
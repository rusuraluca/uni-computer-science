#include <iostream>

void func(int* x) {
	std::cout << "Pointer to int function called"<<std::endl;
}
void func(int x) {
	std::cout << "Int function called" << std::endl;
}
int main()
{
	system("color f4");
	func(0);
	func(NULL);
	func(nullptr);
	
}


#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// complex number a + i b 
// computes the mag & phase of the complex number
// mag = sqrt(a*a + b*b) , phase = atan(b/a)

// 
// mag and phase are pointer
void compute_mag_phase(double a, double b, double* mag, double* phase) {
	
	if(phase != NULL)
		*phase = atan(b / a); //phase -> is a pointer;
	*mag = sqrt(a * a + b * b);
	
	// mag has the type double*
	double** addrMag = &mag;
	
	printf("IN FUNCTION The mag and phase are %f \n", *mag);
	if (phase)
		printf("and phase %f", *phase);
}

int main() {

	int arr[100000000];
	char c = 'a';
	short s = 2;
	int i = 4;

	char* pc = &c;
	short* ps = &s;
	int* pi = &i;

	printf("pc %p %p %ld\n", pc, pc + 1, (pc+1) - pc);
	printf("ps %p %p %ld\n", ps, ps + 1, (ps +1)-ps);
	printf("pi %p %p %ld\n", pi, pi + 1, (pi + 1) -pi);
	return 0;
	double a = 10;
	double b = 20;
	double mag = 0;
	double phase = 0;
	// pass by value

	// scanf is a function
	//scanf("%lf", &a);

	// mag and phase eneed to be pointers
	// mag - double; address of mag -> & 
	// <type> v; &v -> <type>*
	compute_mag_phase(a, b, &mag, NULL);


	printf("The mag and phase are %f %f\n", mag, phase);

	int v = 10;
	
	const int* const pv = &v; // pointer to a constat data
	// *pv = 20; // !!

	 int x = 20;
	 //pv = &x;


	

	//// <type>* <name_of_variable>
	//double* pD = NULL; // store memory location

	//double var = 2;
	//// & - the address of operator - where is that variable stored in memory
	//pD = &var;

	//printf("The pointer is %p ", pD);
	//// * - defreferncing : the value from a pointer: what value is stored in the pointer
	//printf("The value stored at the pointer is %f\n", *pD);
	//var = 4;
	//printf("The value stored at the pointer is %f\n", *pD);

	return 0;
}
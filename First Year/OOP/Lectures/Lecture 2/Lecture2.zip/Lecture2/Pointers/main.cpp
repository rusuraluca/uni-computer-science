#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main() {

	system("color f4");
	int var = 789;

	int *ptr;
	int **ptr_ptr;
	
	//printf("Value of ptr is %p ", ptr);

	ptr = &var;
	ptr_ptr = &ptr;

	
	printf("Value of var = %d\n", var);
	printf("Address of var = %p\n", &var);
	printf("Value of ptr = %p \n", ptr);
	printf("Address of ptr = %p \n", &ptr);
	printf("Value of var using single pointer = %d\n", *ptr);
	printf("Value of var using double pointer = %d\n", **ptr_ptr);

	*ptr = 10;
	
	*ptr++;

	printf("Value stored at ptr = %d\n", *ptr);
	printf("Value of ptr %p\n", ptr);
	printf("Value of ptr_ptr %p \n", ptr_ptr);

	*ptr--;
	printf("Value stored at ptr = %d\n", *ptr);
	(*ptr)--;
	printf("Value stored at ptr = %d\n", *ptr);

	// this declares a pointer to float (ptr_f) and a float variable (f)
	float *ptr_f, f;
	ptr_f = &f;
	*ptr_f = 9.5;

	printf("Valure of f is %f ", f);

	return 0;
}


// the increment (++) operator is applied first and only then the dereferencing operator (*)
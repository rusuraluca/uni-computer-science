#include <windows.h>
#include <stdio.h>

int main()
{
	system("color f4");
	
	int a = 9;
	const int* p1 = &a; // the pointed value cannot be changed
	//*p1 = 10; // error - the value cannot be changed
	int b = 8;
	p1 = &b;  // ok - the pointer can be changed to point somewhere else

	int* const p2 = &a;	// the value can be changed, but not the pointer
	*p2 = 10;	// ok - the value can be changed
	//p2 = &b; // error - the pointer cannot be changed to point somewhere else

	const int* const p3 = &a; // neither the value, not the pointer can be changed
	//*p3 = 11;	// error
	//p3 = &b;	// error

	return 0;
}
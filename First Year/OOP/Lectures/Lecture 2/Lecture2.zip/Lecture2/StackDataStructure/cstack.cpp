#include "cstack.h"

#include <iostream>
using namespace std;

bool push(Stack &s, int x)
{
	if (s.top >= (CAPACITY - 1)) {
		cout << "Stack Overflow";
		return false;
	}
	else {
		s.arr[++s.top] = x;
		cout << x << " pushed into stack\n";
		return true;
	}
}

int pop(Stack& s)
{
	if (s.top < 0) {
		cout << "Stack Underflow";
		return 0;
	}
	else {
		int x = s.arr[s.top--];
		return x;
	}
}

int peek(Stack &s)
{
	if (s.top < 0) {
		cout << "Stack is Empty";
		return 0;
	}
	else {
		int x = s.arr[s.top];
		return x;
	}
}

bool isEmpty(Stack &s)
{
	return (s.top < 0);
}


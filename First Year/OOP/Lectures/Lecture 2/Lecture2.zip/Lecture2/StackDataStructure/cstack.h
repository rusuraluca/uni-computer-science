#pragma once
#define CAPACITY 1000 


typedef struct{
	int top; // index for the top of the stack
	int arr[CAPACITY];  // capacity - maximum numbers of elements the stack can hold
}Stack;

bool push(Stack& s, int x);
int pop(Stack &s);
int peek(Stack& s);
bool isEmpty(Stack& s);

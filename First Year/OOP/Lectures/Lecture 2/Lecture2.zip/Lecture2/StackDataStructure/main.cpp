#include <iostream>
using namespace std;

#include "cstack.h"

// consts using define directive
#define PI 3.1415

// function like macro
#define circleArea(r) (PI*(r)*(r)) 


int main()
{

	double radius = 3;
	double area = circleArea(radius);

	cout << "The area of the circle with radius " << radius << " is " << area<<endl;
	cout << "The values of PI is " << PI << endl;

	Stack s;
	s.top = -1;
	push(s, 10);
	push(s, 20);
	push(s, 30);
	cout << pop(s) << " Popped from stack\n";

	return 0;
}

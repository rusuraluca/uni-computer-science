#include <QLabel>
#include <QApplication>

#include <iostream>
using std::cerr;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv); // creating a QApplication, that handles the event loop.

    // !!! The QApplication object must be created before any widget Object !!!
    QLabel helloLabel{"Hello world!"}; // creating a new label, which will contain the string "Hello world!"
    helloLabel.show(); // show the label

    // we also have access to the command line parameters:
    cerr<<"The number of command line parameters are: "<< argc<<"\n";
    cerr<<"\tThe name of the application is: "<<argv[0]<<"\n"; // always the first command line parameter is the name of the executable
    for(int idx = 1; idx < argc; idx++)
        cerr<<"\tThe "<<idx<<"th command line parameter is: "<<argv[idx]<<"\n";

    // now let's see where is our executable stored on the file system
    // applicationDirPath() and applicationFilePath(), return a QString (i.e. the class from Qt that is used to interact with strings)
    // We cannot use a QString with cout or cerr. Why is that?
    // But we can use a std::string with cout or cerr. So we convert the QString to a std::string using the toStdString method
    cerr<<"The application directory path is "<<a.applicationDirPath().toStdString()<<"\n";
    // applicationFilePath (and applicationDirPath) are static methods, so we can call them without an object, like in the line below
    cerr<<"The path to the executable of our program is "<<QApplication::applicationFilePath().toStdString()<<"\n";

    return a.exec(); // start the application's event loop
}





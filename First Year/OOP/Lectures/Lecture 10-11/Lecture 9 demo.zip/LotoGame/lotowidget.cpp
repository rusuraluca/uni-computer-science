#include "lotowidget.h"

#include <QLabel>
#include <QDebug>
#include <QThread>
#include <QPushButton>
#include <QHBoxLayout>
#include <QApplication>

LotoWidget::LotoWidget(QWidget *parent)
    : QWidget(parent)
{


    this->initGUI();
}

LotoWidget::~LotoWidget()
{
}

void LotoWidget::generateNumbers()
{
    // randomly choose 6 numbers, from 1 to 49 and show them
    std::vector<int> v(6);
    std::iota(v.begin(), v.end(), 0); // fill the vector with sequentially incresing values
    std::vector<int> alreadyGenerated;

    // generate numbers one by one
    for (auto i : v)
    {
        int randNum = 0;
        do{
            randNum = rand() % 49 + 1;
            ((QLabel*)m_horizLayout->itemAt(i)->widget())->setText(QString::number(randNum));

        }while (std::find(alreadyGenerated.begin(), alreadyGenerated.end(), randNum) != alreadyGenerated.end());


        alreadyGenerated.push_back(randNum);
    }

}

void LotoWidget::initGUI()
{
    // set a green background on the widget
    QPalette pal = palette();
    pal.setColor(QPalette::Window, Qt::darkGreen);
    this->setAutoFillBackground(true);
    this->setPalette(pal);

    srand(time(NULL)); // set a seed for the rand() function

    m_horizLayout = new QHBoxLayout{ this };

    // randomly choose 6 numbers, from 1 to 49 and show them
    std::vector<int> v(6);


    for (auto i : v){
        // create uneditable labels which will hold the generated numbers
        QLabel* no = new QLabel{ "" };
        // optionally, you can style a label
        no->setStyleSheet("margin-left: 10px; border: 1px solid black; border-radius: 10px; background: white; color: red;");

        QFont font("Courier", 40, 10, true);
        no->setFont(font);
        m_horizLayout->addWidget(no);
    }

    // add a close button, with a slot
    QPushButton *closeButton = new QPushButton("&Close");
    QObject::connect(closeButton, &QPushButton::clicked, QApplication::instance(), &QApplication::quit);

    QPushButton *generateButton = new QPushButton("&Generate");
    QObject::connect(generateButton, &QPushButton::clicked, this, &LotoWidget::generateNumbers);
    m_horizLayout->addWidget(generateButton);
    m_horizLayout->addWidget(closeButton);
}



#include "lotowidget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LotoWidget w;
    w.show();
    w.generateNumbers();
    return a.exec();
}

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QHBoxLayout>

class LotoWidget : public QWidget
{
    Q_OBJECT
public:
    LotoWidget(QWidget *parent = nullptr);
    ~LotoWidget();
public slots:
    void generateNumbers();
private:
    void initGUI();
    QHBoxLayout* m_horizLayout;
};
#endif // MAINWINDOW_H
